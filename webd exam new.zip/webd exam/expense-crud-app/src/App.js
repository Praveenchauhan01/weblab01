import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import ExpenseForm from "./components/ExpenseForm";
import ExpenseList from "./components/ExpenseList";
import "./App.css";


const App = () => {
  const [expenses, setExpenses] = useState([]);
  const [editExpense, setEditExpense] = useState(null);

  const addExpense = (expense) => {
    setExpenses([...expenses, { ...expense, id: uuidv4() }]);
  };

  const updateExpense = (updatedExpense) => {
    setExpenses(
      expenses.map((exp) =>
        exp.id === updatedExpense.id ? updatedExpense : exp
      )
    );
    setEditExpense(null);
  };

  const deleteExpense = (id) => {
    setExpenses(expenses.filter((exp) => exp.id !== id));
  };

  return (
    <div className="app-container">
      <h1>Expense Tracker</h1>
      <ExpenseForm
        addExpense={addExpense}
        editExpense={editExpense}
        updateExpense={updateExpense}
      />
      <ExpenseList
        expenses={expenses}
        setEditExpense={setEditExpense}
        deleteExpense={deleteExpense}
      />
    </div>
  );
};

export default App;
