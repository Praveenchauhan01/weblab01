import React from "react";

const ExpenseList = ({ expenses, setEditExpense, deleteExpense }) => {
  return (
    <div>
      <h2>Expenses</h2>
      <table border="1">
        <thead>
          <tr>
            <th>Title</th>
            <th>Amount ($)</th>
            <th>Category</th>
            <th>Date</th>
            <th>Payment Method</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {expenses.map((exp) => (
            <tr key={exp.id}>
              <td>{exp.title}</td>
              <td>{exp.amount}</td>
              <td>{exp.category}</td>
              <td>{exp.date}</td>
              <td>{exp.paymentMethod}</td>
              <td>
                <button onClick={() => setEditExpense(exp)}>Edit</button>
                <button onClick={() => deleteExpense(exp.id)}>Delete</button>
              </td>
            </tr>
          ))}
          {expenses.length === 0 && (
            <tr>
              <td colSpan="6">No expenses added yet.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ExpenseList;
