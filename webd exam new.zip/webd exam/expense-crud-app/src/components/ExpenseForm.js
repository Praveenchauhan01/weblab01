import React, { useEffect, useState } from "react";

const ExpenseForm = ({ addExpense, editExpense, updateExpense }) => {
  const [formData, setFormData] = useState({
    title: "",
    amount: "",
    category: "",
    date: "",
    paymentMethod: "",
  });

  useEffect(() => {
    if (editExpense) setFormData(editExpense);
  }, [editExpense]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editExpense) updateExpense(formData);
    else addExpense(formData);

    setFormData({
      title: "",
      amount: "",
      category: "",
      date: "",
      paymentMethod: "",
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        name="title"
        placeholder="Title"
        value={formData.title}
        onChange={handleChange}
        required
      />
      <input
        name="amount"
        type="number"
        placeholder="Amount"
        value={formData.amount}
        onChange={handleChange}
        required
      />
      <input
        name="category"
        placeholder="Category"
        value={formData.category}
        onChange={handleChange}
        required
      />
      <input
        name="date"
        type="date"
        value={formData.date}
        onChange={handleChange}
        required
      />
      <input
        name="paymentMethod"
        placeholder="Payment Method"
        value={formData.paymentMethod}
        onChange={handleChange}
        required
      />
      <button type="submit">{editExpense ? "Update" : "Add"} Expense</button>
    </form>
  );
};

export default ExpenseForm;
